import Replicate from "replicate";

const MODEL = "codeslake/ifan-defocus-deblur:ea3b2e163e2ad629fb23e81a1cc9e485c32aa4a53eba4fe08b7dbdd39e6e381e";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"Method not allowed"});
  try {
    const { image } = req.body || {};
    if (!image || typeof image !== "string" || !image.startsWith("data:image/")) {
      return res.status(400).json({error:"Brak prawidłowego obrazu."});
    }
    if (image.length > 1200000) {
      return res.status(413).json({error:"Obraz jest za duży. Spróbuj mniejszego pliku."});
    }
    if (!process.env.REPLICATE_API_TOKEN) {
      return res.status(500).json({error:"Brak REPLICATE_API_TOKEN na serwerze."});
    }

    const replicate = new Replicate({auth: process.env.REPLICATE_API_TOKEN});
    const output = await replicate.run(MODEL, {input:{image}});

    const url = typeof output === "string" ? output :
      (output && typeof output.url === "function" ? output.url() :
      (Array.isArray(output) ? (typeof output[0] === "string" ? output[0] : output[0]?.url) : null));

    if (!url) throw new Error("Model nie zwrócił adresu wyniku.");
    return res.status(200).json({output:url});
  } catch (e) {
    console.error(e);
    return res.status(500).json({error:e?.message || "Błąd modelu AI."});
  }
}